CREATE VIEW semestroproj.show_all_list_with_steps_and_tasks AS
  SELECT
    `semestroproj`.`todolists`.`order`         AS `todolist_number`,
    `semestroproj`.`todolists`.`name`          AS `todolist_name`,
    `semestroproj`.`steps`.`order_in_todolist` AS `step_order`,
    `semestroproj`.`steps`.`name`              AS `step_name`,
    `semestroproj`.`tasks`.`order_in_steplist` AS `task_order`,
    `semestroproj`.`tasks`.`name`              AS `task_name`,
    `semestroproj`.`tasks`.`state`             AS `state`
  FROM ((`semestroproj`.`todolists`
    JOIN `semestroproj`.`steps` ON ((`semestroproj`.`todolists`.`id` = `semestroproj`.`steps`.`todolist_id`))) JOIN
    `semestroproj`.`tasks` ON ((`semestroproj`.`steps`.`id` = `semestroproj`.`tasks`.`step_id`)))
  ORDER BY `semestroproj`.`todolists`.`order`, `semestroproj`.`steps`.`order_in_todolist`,
    `semestroproj`.`tasks`.`order_in_steplist`;
